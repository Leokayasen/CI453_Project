package com.ci453.ci453_atm_v09;

import java.util.Objects;

// The ATM controller is quite simple - the process method is passed
public class Controller {
    public Model model;
    public View view;
    languageStore lang;
    // we don't really need a constructor method, but include one to print a
    // debugging message if required
    public Controller(languageStore languageStore) {
        lang = languageStore;
        Debug.trace("Controller::<constructor>");
    }
    public boolean isNumber(String str) {
        String[] nums = new String[]{"0","1","2","3","4","5","6","7","8","9"};
        for (int i = 0; i < nums.length; i++) {
            if (str.equals(nums[i])) {
                return true;
            }
        }
        return false;
    }

    // This is how the View talks to the Controller, which talks to the Model
    public void process(String action) {
        Debug.trace("Controller::process: action = " + action);
        boolean hasSound = false;

        if (isNumber(action)) {model.processNumber(action);}
        else if (action.equals(lang.CLEAR)) {model.processClear();}
        else if (action.equals(lang.ENTER)) {model.processEnter();}
        else if (action.equals(lang.WITHDRAW)) {model.processWithdraw();}
        else if (action.equals(lang.DEPOSIT)) {model.processDeposit();}
        else if (action.equals(lang.BALANCE)) {model.processBalance();}
        else if (action.equals(lang.ACCOUNT)) {model.processAccount();}
        else if (action.equals(lang.LOGIN)) {model.proccessLogin();}
        else if (action.equals(lang.FINISH)) {hasSound = true;model.processFinish();}
        else if (action.equals(lang.BACK)) {model.processBack();}
        else if (action.equals(lang.TRANSFER)) {model.ProcessTransfer(false);}
        else if (action.equals(lang.RECEIPT)) {view.showReceipt(model.receipt);}
        else if (action.equals(lang.PASS)) {System.out.println("not implemented yet");}
        else if (action.equals(lang.CREATE)) {model.createAccount();}
        else if (action.equals(lang.NO)) {model.processNo();}
        else if (action.equals(lang.YES)) {model.processYes();}
        else if (action.equals("Lang")) {model.processLanguage();}
        else if (action.equals("English") || action.equals("Ingles")) {model.changeLanguage(action);}
        else{model.processUnknownKey(action);}
        if (!hasSound) {
            view.playButtonSound("ButtonDing.mp3");
        }
    }
}


/*
switch (action) {
            case "1":
            case "2":
            case "3":
            case "4":
            case "5":
            case "6":
            case "7":
            case "8":
            case "9":
            case "0":
                model.processNumber(action);
                break;
            case "CLEAR":
                model.processClear();
                break;
            case "ENTER":
                model.processEnter();
                break;
            case "Withdraw":
                model.processWithdraw();
                break;
            case "Deposit":
                model.processDeposit();
                break;
            case "Balance":
                model.processBalance();
                break;
            case "Account":
                model.processAccount();
                break;
            case "Login":
                model.proccessLogin();
                break;
            case "Finish":
                hasSound = true;
                model.processFinish();
                //view.changeScene("Start");
                break;
            case "Back":
                model.processBack();
                break;
            case "Transfer":
                model.ProcessTransfer(false);
                break;
            case "Receipt":
                view.showReceipt(model.receipt);
                break;
            case "Pass":
                //view.changeScene("ConfirmMenu");
                System.out.println("not implemented yet");
                break;
            case "Create":
                model.createAccount();
                break;
            case "No":
                model.processNo();
                break;
            case "Yes":
                model.processYes();
                break;
            default:
                model.processUnknownKey(action);
                break;
        }
 */

