package com.ci453.ci453_atm_v09;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.NoSuchElementException;
import java.util.Scanner;

//is used to store all of the words and phrases found in the language files
public class languageStore {
    String defaultLanguage = "English";
    String pathBase = "src/main/resources/KeyData/Languages/";
    public String CLEAR,ENTER,WITHDRAW,DEPOSIT,BALANCE,ACCOUNT,LOGIN,FINISH,BACK,TRANSFER,RECEIPT,PASS,CREATE,NO,YES;
    public String[] titleTexts;
    public String[] displayTexts;
    public languageStore(String languageFilePath) {
        loadLanguage(languageFilePath);
    }
    public void loadLanguage(String langName) {
        String languageFilePath = pathBase + langName;
        System.out.println("Loading language from " + languageFilePath);
        String[] buttonText = new String[15];
        String[] titleText = new String[11];
        String[] displayText = new String[31];
        try {
            File myObj = new File(languageFilePath + "/Buttons.txt");
            Scanner myReader = new Scanner(myObj);
            try {
                for (int i = 0; i < buttonText.length; i++) {
                    buttonText[i] = myReader.nextLine();
                }
            }
            catch (NoSuchElementException e)
            {
                System.out.println("Error : Invalid File Size : " + languageFilePath);
                myReader.close();
                loadLanguage(defaultLanguage);
                return;
            }
            myReader.close();

            //finished getting buttons

            myObj = new File(languageFilePath + "/Titles.txt");
            myReader = new Scanner(myObj);
            try {
                for (int i = 0; i < titleText.length; i++) {
                    titleText[i] = myReader.nextLine();
                }
            }
            catch (NoSuchElementException e)
            {
                System.out.println("Error : Invalid File Size : " + languageFilePath);
                myReader.close();
                loadLanguage(defaultLanguage);
                return;
            }
            myReader.close();

            myObj = new File(languageFilePath + "/Displays.txt");
            myReader = new Scanner(myObj);
            try {
                for (int i = 0; i < displayText.length; i++) {
                    displayText[i] = myReader.nextLine();
                }
            }
            catch (NoSuchElementException e)
            {
                System.out.println("Error : Invalid File Size : " + languageFilePath);
                myReader.close();
                loadLanguage(defaultLanguage);
                return;
            }
            myReader.close();


        } catch (FileNotFoundException e) {
            System.out.println("No Language File Found : "+languageFilePath);
            //loadLanguage(defaultLanguage);
            return;
        }
        setButtons(buttonText);
        titleTexts = titleText;
        displayTexts = displayText;
        //presentLines(displayTexts);
    }
    public void presentLines(String[] lines)
    {
        for (int i = 0; i < lines.length; i++) {
            System.out.println(lines[i]);
        }
    }
    public void setButtons(String[] ButtonData)
    {
        CLEAR = ButtonData[0];
        ENTER = ButtonData[1];
        WITHDRAW = ButtonData[2];
        DEPOSIT = ButtonData[3];
        BALANCE = ButtonData[4];
        ACCOUNT = ButtonData[5];
        LOGIN = ButtonData[6];
        FINISH = ButtonData[7];
        BACK = ButtonData[8];
        TRANSFER = ButtonData[9];
        RECEIPT = ButtonData[10];
        PASS = ButtonData[11];
        CREATE = ButtonData[12];
        NO = ButtonData[13];
        YES = ButtonData[14];
    }
}

/*
CLEAR
ENTER
Withdraw
Deposit
Balance
Account
Login
Finish
Back
Transfer
Receipt
Pass
Create
No
Yes
 */