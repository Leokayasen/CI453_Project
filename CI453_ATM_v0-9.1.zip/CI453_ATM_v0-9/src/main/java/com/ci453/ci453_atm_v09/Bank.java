package com.ci453.ci453_atm_v09;

import com.google.common.hash.Hashing;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.NoSuchElementException;
import java.util.Objects;
import java.util.Scanner;

// Bank class - simple implementation of a bank, with a list of bank accounts,
// a current account that we are logged in to.
public class Bank {
    static String DATAPATH = "src/main/resources/KeyData/BankData.txt";
    // Instance variables containing the bank information
    int nextAccountNumber = 118;
    BankAccount account = null; // currently logged in account ('null' if no-one is logged in)

    // Constructor method - this provides a couple of example bank accounts to work with

    //        117,f6e0a1e2ac41945a9aa7ff8a8aaa0cebc12a3bcc981a929ad5cf810a090e11ae,100,PREMIUM,0
    //        102,9b871512327c09ce91dd649b3f96a63b7408ef267c8cc5710114e629730cb61f,50,BASIC,0

    public Bank() {
        Debug.trace("DEBUG | Bank::Bank(<constructor>)");
        nextAccountNumber += getWholeData().size();
    }

    public void replaceData(String oldData,String newData)//use this to rewrite all data
    {
        String encryptedLine = Encryptor.encryptLine(oldData);
        ArrayList<String> lines = getWholeData();
        for (int i = 0;i < lines.size();i++){
            if (lines.get(i).equals(encryptedLine))
            {
                //now rewrite all of the data with this change


                try {//todo write passwords to text file
                    FileWriter myWriter = new FileWriter(DATAPATH,false);
                    for (int j = 0;j < lines.size();j++)
                    {
                        if (j != i)
                        {
                            myWriter.write(lines.get(j) + "\n");
                        }
                        else{
                            myWriter.write(Encryptor.encryptLine(newData) + "\n");
                        }
                    }
                    myWriter.close();
                    System.out.println("Successfully updated data file.");
                } catch (IOException e) {
                    System.out.println("Error occured updating data file");
                }
                return;

            }
        }
        return;
    }
    public ArrayList<String> getWholeData()//use this to rewrite all data
    {
        ArrayList<String> lines = new ArrayList<>();
        try {
            File myObj = new File(DATAPATH);
            Scanner myReader = new Scanner(myObj);
            try {
                while (true)
                {
                    lines.add(myReader.nextLine());
                }
            }
            catch (NoSuchElementException e)
            {
                myReader.close();
            }
        } catch (FileNotFoundException e) {
            System.out.println("An error occurred while reading");
        }
        return lines;
    }

    public String getDataSection(String accNumber)
    {
        try {
            File myObj = new File(DATAPATH);
            Scanner myReader = new Scanner(myObj);
            String line = "";
            String accSection = "";
            try {
                while (true)
                {
                    line = Encryptor.decryptLine(myReader.nextLine());
                    accSection = line.substring(0,line.indexOf(","));
                    if (accSection.equals(accNumber))
                    {
                        myReader.close();
                        return line;
                    }
                }
            }
            catch (NoSuchElementException e)
            {
                myReader.close();
                return null;
            }
        } catch (FileNotFoundException e) {
            System.out.println("An error occurred while reading");
        }
        return null;
    }

    // a variant of addBankAccount which makes the account and adds it all in one go.
    // Using the same name for this method is called 'method overloading' - two methods
    // can have the same name if they take different argument combinations

    public boolean addBankAccount(String password)
    {
        if (addBankAccount(nextAccountNumber,password,0,AccountType.BASIC))
        {
            nextAccountNumber++;
            return true;
        }
        else{
            return false;
        }
    }
    public String getRandomSalt(int size)
    {
        //48 - 124 = 48+((int) Math.random()*77) //this means 77 unique combinations meansing a size of 4 has 35153041 unique combinations
        String finalSalt = "";
        for (int i =0; i < size ; i++)
        {
            finalSalt += (char)(48+((int)(Math.random()*77)));
        }
        return finalSalt;
    }
    public boolean addBankAccount(int accNumber, String accPasswd, int balance, AccountType type) {
        String salt = getRandomSalt(4);
        String hashedPasswd = Hashing.sha256()
                .hashString(accPasswd + salt, StandardCharsets.UTF_8)
                .toString();




        BankAccount a = new BankAccount(accNumber, hashedPasswd,salt, balance, type);

        Debug.trace("PasswordString = " + accPasswd);
        Debug.trace("PasswordHash = " + hashedPasswd);

        try {//todo write passwords to text file
            String path = DATAPATH;
            FileWriter myWriter = new FileWriter(path,true);
            myWriter.write("\n" + Encryptor.encryptLine(a.turnToData()));
            myWriter.close();
            System.out.println("Successfully wrote to the file.");
        } catch (IOException e) {
            System.out.println("Error occured writing to file");
        }
        Debug.trace("DEBUG | Bank::addBankAccount()" +
                a.accNumber+" "+hashedPasswd +" £"+a.balance);
        return true;
    }
    public boolean login(int newAccNumber, String AccPasswd) {
        //assigns account to the account that was foind
        Debug.trace("DEBUG | Bank::login: accNumber = " + newAccNumber);
        logout();
        String fileData = getDataSection(newAccNumber +"");
        if (fileData != null)
        {
            String[] passData = getPasswordData(fileData);
            String hashedPasswd = Hashing.sha256()
                    .hashString(AccPasswd + passData[1], StandardCharsets.UTF_8)
                    .toString();
//            System.out.println(passData[0]);
//            System.out.println(passData[1]);
//            System.out.println(fileData);
            if (passData[0].equals(hashedPasswd))
            {
                System.out.println(fileData.length());
                account = new BankAccount(fileData);
                return true;
            }
        }

        // not found - return false
        account = null;
        return false;
    }
    public String[] getPasswordData(String fileData)
    {
        int dataPoint = fileData.indexOf(",");
        String pas = fileData.substring(dataPoint + 1,dataPoint + 65);
        String salt = fileData.substring(dataPoint + 65,dataPoint + 65 + 4);
        return new String[]{pas,salt};
    }
//    public boolean login(int newAccNumber, String AccPasswd) {
//        //assigns account to the account that was foind
//        Debug.trace("DEBUG | Bank::login: accNumber = " + newAccNumber);
//        logout();
//
//        String hashedPasswd = Hashing.sha256()
//                .hashString(AccPasswd, StandardCharsets.UTF_8)
//                .toString();
//
//        Debug.trace("DEBUG | hashedPasswd = "+hashedPasswd);
//
//        for (int i = 0; i <= numAccounts - 1; i++) {
//            if (accounts[i].accNumber == newAccNumber) {
//                if(accounts[i].accPasswd.equals(hashedPasswd)){
//                    account = accounts[i];
//                    return true;
//                }
//            }
//        }
//
//        // not found - return false
//        account = null;
//        return false;
//    }

    // Reset the bank to a 'logged out' state
    public void logout() {
        if (loggedIn()) {
            Debug.trace("DEBUG | Bank::logout: logging out, accNumber = " + account.accNumber);
            account = null;
        }
    }

    // test whether the bank is logged in to an account or not
    public boolean loggedIn() {
        if (account == null) {
            return false;
        } else {
            return true;
        }
    }

    // try to deposit money into the account (by calling the deposit method on the
    // BankAccount object)
    public boolean deposit(int amount) {
        if (loggedIn()) {
            boolean returnBool = account.deposit(amount);
            account.updateAccountData(this);
            return returnBool;
        } else {
            return false;
        }
    }

    public boolean transferMoney(int ID,int amount) {
        String dataSection = getDataSection(ID + "");
        if (dataSection == null || account.withdraw(amount) != 1)//turn this into a bank account then withdraw and then coninue
        {
            return false;
        }
        BankAccount receiver = new BankAccount(dataSection);
        receiver.deposit(amount);
        receiver.updateAccountData(this);
        account.updateAccountData(this);
        return true;
    }
//    int limit = 0;
//            for (int i = 0;i<2;i++)
//    {
//        limit = dataSection.indexOf(",",limit);
//    }
//    String newData = dataSection.substring(0,limit) +amount+ dataSection.substring(limit + 1);
}
