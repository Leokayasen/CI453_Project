package com.ci453.ci453_atm_v09;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Arrays;

public class encryptionTest {
    //this was used to test enctyption but should be unused now
    final byte[] test = new byte[]{77, -93, -116, 111, -98, 98, -52, 118, -43, -18, -105, -73, -57, -128, -116, -23, -83, 81, 10, 105, 96, 39, 57, 61, 118, -9, -84, 44, -32, -96, -80, 63};
    public byte[] encryptLine(String line){
        try{
            SecretKey secretKey = new SecretKeySpec(test, "AES");
            Cipher desCipher = Cipher.getInstance("AES");
            byte[] text = line.getBytes("UTF8");
            desCipher.init(Cipher.ENCRYPT_MODE, secretKey);
            byte[] textEncrypted = desCipher.doFinal(text);

            return textEncrypted;
        }catch(Exception e)
        {
            System.out.println("Failed to Encrypt");
        }
        return null;
    }
    public String decryptLine(byte[] line){
        try{
            SecretKey secretKey = new SecretKeySpec(test, "AES");
            Cipher desCipher = Cipher.getInstance("AES");


            desCipher.init(Cipher.DECRYPT_MODE, secretKey);
            byte[] textDecrypted = desCipher.doFinal(line);

            String s = new String(textDecrypted);
            return s;
        }catch(Exception e)
        {
            System.out.println("Exception");
        }
        return null;
    }
    public static void main(String[] args) throws UnsupportedEncodingException {
        byte[] encrypted = new encryptionTest().encryptLine("Hello\nWorld");
        System.out.println(Arrays.toString(encrypted));
        String decrypted = new encryptionTest().decryptLine(stringToByte(Arrays.toString(encrypted)));
        System.out.println(decrypted);
    }
    public static byte[] stringToByte(String s){
        ArrayList<Byte> list = new ArrayList<>();
        int point = s.indexOf(",");
        list.add(Byte.parseByte(s.substring(1, point)));
        while (true)
        {
            int lastPoint = point;
            point = s.indexOf(",", point+1);
            if (point == -1)
            {
                list.add(Byte.parseByte(s.substring(lastPoint+2, s.indexOf("]"))));
                break;
            }
            else{
                list.add(Byte.parseByte(s.substring(lastPoint+2, point)));
            }
        }
        byte[] bytes = new byte[list.size()];//havent even accounter for the end yet
        for (int i = 0; i < list.size(); i++)
        {
            bytes[i] = list.get(i);
        }
        return bytes;
    }
}
