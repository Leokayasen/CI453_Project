package com.ci453.ci453_atm_v09;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import java.util.ArrayList;
import java.util.Arrays;

public class Encryptor {
    static byte[] test = new byte[]{77, -93, -116, 111, -98, 98, -52, 118, -43, -18, -105, -73, -57, -128, -116, -23, -83, 81, 10, 105, 96, 39, 57, 61, 118, -9, -84, 44, -32, -96, -80, 63};
    static public String encryptLine(String line){
        try{
            SecretKey secretKey = new SecretKeySpec(test, "AES");
            Cipher desCipher = Cipher.getInstance("AES");
            byte[] text = line.getBytes("UTF8");
            desCipher.init(Cipher.ENCRYPT_MODE, secretKey);
            byte[] encrypted = desCipher.doFinal(text);
            return Arrays.toString(encrypted);
        }catch(Exception e)
        {
            System.out.println("Failed to Encrypt");
        }
        return null;
    }
    static public String decryptLine(String line){
        return decryptLine(stringToByte(line));
    }
    static public String decryptLine(byte[] line){
        try{
            SecretKey secretKey = new SecretKeySpec(test, "AES");
            Cipher desCipher = Cipher.getInstance("AES");


            desCipher.init(Cipher.DECRYPT_MODE, secretKey);
            byte[] textDecrypted = desCipher.doFinal(line);

            return new String(textDecrypted);
        }catch(Exception e)
        {
            System.out.println("Failed to Decrypt");
        }
        return null;
    }
    public static byte[] stringToByte(String s){
        ArrayList<Byte> list = new ArrayList<>();
        int point = s.indexOf(",");
        list.add(Byte.parseByte(s.substring(1, point)));
        while (true)
        {
            int lastPoint = point;
            point = s.indexOf(",", point+1);
            if (point == -1)
            {
                list.add(Byte.parseByte(s.substring(lastPoint+2, s.indexOf("]"))));
                break;
            }
            else{
                list.add(Byte.parseByte(s.substring(lastPoint+2, point)));
            }
        }
        byte[] bytes = new byte[list.size()];//havent even accounter for the end yet
        for (int i = 0; i < list.size(); i++)
        {
            bytes[i] = list.get(i);
        }
        return bytes;
    }
}
