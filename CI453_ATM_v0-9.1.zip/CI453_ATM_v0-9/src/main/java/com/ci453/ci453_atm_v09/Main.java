package com.ci453.ci453_atm_v09;

import javafx.application.Application;
import javafx.stage.Stage;

public class Main extends Application {
    languageStore lang;
    public void start(Stage window) {
        Debug.set(false);
        Debug.trace("DEBUG | ATM starting");
        Debug.trace("DEBUG | Main::start()");

        // Create a Bank object for this ATM
        Bank b = new Bank();
        // add some test bank accounts


//        b.addBankAccount(117, "111", 100, AccountType.PREMIUM);
//        b.addBankAccount(102, "222", 50, AccountType.BASIC);
//        b.addBankAccount(118, "145745", (int) (Math.random() * 1000), AccountType.BASIC);
//        b.addBankAccount(119, "224864862", (int) (Math.random() * 1000), AccountType.BASIC);
//        b.addBankAccount(120, "484866346", (int) (Math.random() * 1000), AccountType.BASIC);
//        b.addBankAccount(121, "48634384", (int) (Math.random() * 1000), AccountType.BASIC);
//        b.addBankAccount(122, "48645263", (int) (Math.random() * 1000) + 150, AccountType.SAVINGS);
//        b.addBankAccount(123, "4564845", (int) (Math.random() * 1000) + 100, AccountType.STUDENT);

        // Create the Model, View and Controller objects
        //"src/main/resources/KeyData/Languages/English.txt"
        //src/main/resources/KeyData/Languages/Spanish.txt
        lang = new languageStore("English");
        Model model = new Model(b,lang);   // the model needs the Bank object to 'talk to' the bank
        View view = new View(lang);
        Controller controller = new Controller(lang);


        // Link them together so that they can talk to each other
        // Each one has instances variable for the other two
        model.title = "";
        model.view = view;
        model.controller = controller;

        controller.model = model;
        controller.view = view;

        view.model = model;
        view.controller = controller;

        // start up the GUI (view), and then tell the model to initialise and display itself
        view.start(window);
        model.initialise("Welcome to the ATM");
        view.update();
    }
}
