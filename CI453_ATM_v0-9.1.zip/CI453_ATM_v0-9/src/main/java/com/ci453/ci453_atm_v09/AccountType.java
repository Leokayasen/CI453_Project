package com.ci453.ci453_atm_v09;

public enum AccountType {
    BASIC,
    PREMIUM,
    SAVINGS,
    STUDENT
}
