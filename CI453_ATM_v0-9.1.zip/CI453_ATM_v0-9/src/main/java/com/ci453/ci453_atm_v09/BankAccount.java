package com.ci453.ci453_atm_v09;

// BankAccount class
// This class has instance variables for the account number, password and balance, and methods to withdraw, deposit, check balance etc.

public class BankAccount {
    public int accNumber = 0;
    public String accPasswd = "0";
    public String accSalt = "";
    public int balance = 0;
    public int overdraft = 0;
    public int defaultOverdraft = 0;
    public int withdrawLimit = 0;
    AccountType accType;

    //number,pass,balance,type,current overdraft

    public BankAccount(String fileData)
    {
        int secondPost = fileData.indexOf(",");
        accNumber = Integer.parseInt(fileData.substring(0,secondPost));
        accPasswd = fileData.substring(secondPost + 1,secondPost + 65);
        accSalt = fileData.substring(secondPost + 65,secondPost + 65 + 4);
        int currentPost = fileData.indexOf(",",secondPost + 65 + 3);
        secondPost = fileData.indexOf(",",currentPost+1);
        balance = Integer.parseInt(fileData.substring(currentPost+1,secondPost));
        currentPost =  fileData.indexOf(",",secondPost + 1);
        String type = fileData.substring(secondPost + 1,currentPost);
        switch(type){
            case "BASIC":
                withdrawLimit = 500;
                defaultOverdraft = 0;
                accType = AccountType.BASIC;
                break;
            case "PREMIUM":
                withdrawLimit = 1000000;
                defaultOverdraft = 2000;
                accType = AccountType.PREMIUM;
                break;
            case "SAVINGS":
                withdrawLimit = 1000000000;
                defaultOverdraft = 0;
                accType = AccountType.SAVINGS;
                break;
            case "STUDENT":
                withdrawLimit = 1000000000;
                defaultOverdraft = 1000;
                accType = AccountType.STUDENT;
                break;
            case null, default:
                withdrawLimit = 1000;
                defaultOverdraft = 500;
                accType = null;
                break;
        }
        overdraft = Integer.parseInt(fileData.substring(currentPost + 1));
    }
    public BankAccount(int num, String pass,String accSalt, int bal, AccountType type) {
        accNumber = num;
        accPasswd = pass;
        this.accSalt =accSalt;
        balance = bal;
        accType = type;
        switch(type){
            case BASIC:
                withdrawLimit = 500;
                defaultOverdraft = 0;
                break;
            case PREMIUM:
                withdrawLimit = 1000000;
                defaultOverdraft = 2000;
                break;
            case SAVINGS:
                withdrawLimit = 1000000000;
                defaultOverdraft = 0;
                break;
            case STUDENT:
                withdrawLimit = 1000000000;
                defaultOverdraft = 1000;
                break;
            case null, default:
                withdrawLimit = 1000;
                defaultOverdraft = 500;
                break;
        }
        overdraft = defaultOverdraft;
    }


    // withdraw money from the account. Return true if successful, or
    // false if the amount is negative, or less than the amount in the account
    public byte withdraw(int amount) {
        Debug.trace("BankAccount::withdraw: amount =" + amount);
        if (amount>withdrawLimit) {
            return 3;
        }
        int newAmount = balance - amount;
        if (newAmount < 0) {
            if (overdraft + newAmount < -defaultOverdraft) {
                Debug.trace("Overdraft too low to withdraw");
                return 2;
            } else if (balance >= 0) {
                overdraft += newAmount;
                balance -= amount;
                return 1;
            } else {
                overdraft -= amount;
                balance -= amount;
                return 1;
            }
        } else {
            balance = newAmount;
            return 1;
        }
    }
    public boolean isLow()
    {
        if (balance < 100)
        {
            return true;
        }
        return false;
    }

    // deposit the amount of money into the account. Return true if successful,
    // or false if the amount is negative
    public boolean deposit(int amount) {
        Debug.trace("LocalBank::deposit: amount = " + amount);
        int newAmount = overdraft + amount;
        int newBalance = balance + amount;
        if (newBalance > 1000000000){
            Debug.trace("account limit exceeded. Deposit rejected.");
            return false;
        } else

        if (newAmount >= defaultOverdraft) {
            overdraft = defaultOverdraft;
        } else {
            overdraft = overdraft + amount;
        }
        balance = balance + amount;
        return true;
    }

    // Return the current balance in the account
    public int getBalance() {
        Debug.trace("LocalBank::getBalance");
        return balance;
    }

    public int getOverdraft() {
        Debug.trace("LocalBank::getOverdraft");
        return overdraft;
    }

    void updateAccountData(Bank accountBank)
    {
        accountBank.replaceData(accountBank.getDataSection(accNumber + ""),turnToData());
    }
    public String turnToData()
    {
        return accNumber + "," + accPasswd + accSalt + "," + balance + "," + accType + "," + overdraft;
    }
}

