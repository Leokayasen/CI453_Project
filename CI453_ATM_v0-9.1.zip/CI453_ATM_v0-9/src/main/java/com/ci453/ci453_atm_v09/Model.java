package com.ci453.ci453_atm_v09;

import java.util.Objects;

// The model represents all the actual content and functionality of the app.
public class Model {
    final String ACCOUNT_NO = "account_no";
    final String PASSWORD = "password";

    final String LOGGED_IN = "logged_in";
    final String SETTINGS = "settings";

    final String MANAGMENT = "manage";
    final String WITHDRAW = "withdraw";
    final String DEPOSIT = "deposit";
    final String ACCOUNTCREATION = "accCreate";
    final String MONEYTRANSFER = "monTrans";

    // variables representing the ATM model
    String state = ACCOUNT_NO;
    int number = 0;
    Bank bank = null;
    int accNumber = -1;
    String accPasswd = "";
    String accPasswordStore = "";
    languageStore lang;

    // These three are what are shown on the View display
    String title = "Bank ATM";
    String titl2 = "";
    String display1 = "";
    String display2 = "";
    String display3 = "";

    // The other parts of the model-view-controller setup
    public View view;
    public Controller controller;
    String receipt = "";//todo fit this to the given language

    // Model constructor - we pass it a Bank object representing the bank we want to talk to
    public Model(Bank b,languageStore l) {
        Debug.trace("DEBUG | Model::Model()");
        lang = l;
        title = lang.titleTexts[0];
        bank = b;
    }

    public void processLanguage()
    {
        view.changeScene("Language");
        title = lang.titleTexts[10];
        view.update();
    }

    public void changeLanguage(String language)
    {
        lang.loadLanguage(language);
        //view.changeScene("Language");
        view.changeScene("Language");
        title = lang.titleTexts[10];
        view.update();
    }

    // Initialising the ATM (or resetting after an error or logout)
    public void initialise(String message) {
        setState(ACCOUNT_NO);
        number = 0;
        display1 = message;
        display2 = lang.displayTexts[1]+"\n" +
                lang.displayTexts[2]+"\""+lang.ENTER+"\"";
    }

    // use this method to change state - mainly so we print a debugging message whenever the state changes
    public void setState(String newState) {
        if (!state.equals(newState)) {
            String oldState = state;
            state = newState;
            Debug.trace("DEBUG | Model::setState(): changed state from " + oldState + " to " + newState);
        }
    }

    // process a number key (the key is specified by the label argument)
    public void processNumber(String label) {
        // a little magic to turn the first char of the label into an int and update number
        char c = label.charAt(0);
        if (state.equals("password"))
        {
            if (accPasswd.length() == 0)
            {
                display1 = "";
            }
            accPasswd += c;
            display1 += "*";
        }
        else if (state.equals(ACCOUNTCREATION))
        {
            if (accNumber == -1)
            {
                display1 += "*";
                accPasswd += c;
            }
            else{
                display3 += "*";
                accPasswordStore += c;
            }
            System.out.println(accPasswd);
            System.out.println(accPasswordStore);
        }
        else if (state.equals(MONEYTRANSFER))
        {
            if (Objects.equals(accPasswd, ""))
            {
                if (number <= 99999999) {
                    number = number * 10 + c - '0';
                    display1 = "" + number;
                }
            }
            else{
                if (number <= 99999999) {
                    number = number * 10 + c - '0';
                    display3 = "" + number;
                }
            }
        }
        else{
            number = number * 10 + c - '0';
            if (number > 99999999) {
                display2 = lang.displayTexts[3] + "\n";// "ERROR: You cannot enter a larger value than 99999999.";
                number = 0;
            }
            display1 = "" + number;
        }
        System.out.println("The state is : " + state);
        view.update();  // update the GUI
    }

    // process the Clear button - reset the number (and number display string)
    public void processClear() {
        // clear the number stored in the model
        if (state.equals(ACCOUNTCREATION))
        {
            if (Objects.equals(accPasswordStore, ""))
            {
                accPasswd = "";
            }
            else{
                accPasswordStore = "";
            }
        }
        if (state.equals(PASSWORD))
        {
            accPasswd = "";
        }
        number = 0;
        display1 = "";
        view.update();  // update the GUI
    }
    public void toTransition()
    {
        setState(MANAGMENT);
        view.changeScene("Transition");
        display1 = "";
        display2 = lang.displayTexts[12]+" " + bank.account.getBalance() +
                "\n"+lang.displayTexts[13]+" " + bank.account.getOverdraft();
        title = lang.titleTexts[1];
        number = 0;
        view.update();
    }
    public boolean processEnter() {
        boolean isClosing = false;
        // Enter was pressed - what we do depends on what state the ATM is already in
        switch (state) {
            case ACCOUNT_NO:
                accNumber = number;
                number = 0;
                setState(PASSWORD);
                title = lang.titleTexts[2];
                display1 = "";
                view.changeScene("logPass");
                break;
            case PASSWORD:
                Debug.trace("DEBUG | Model::processEnter() case PASSWORD");
                number = 0;
                display1 = "";
                if (bank.login(accNumber, accPasswd)) {
                    receipt = "Account number - " + accNumber;
                    toTransition();
                } else {
                    proccessLogin();
                    initialise("");
                }
                accPasswd = "";
                accNumber = 0;
                break;
            case WITHDRAW:
                processWithdraw();
                break;
            case ACCOUNTCREATION:
                if (accNumber == -1)
                {
                    accNumber = 0;
                    number = 0;
                    //then inputing first password
                }
                else{
                    if (!Objects.equals(accPasswd, accPasswordStore)){
                        System.out.println(accPasswd +"= pwd");
                        System.out.println(accPasswordStore +"= pwdstr");
                        number = 0;
                        accPasswd = "";
                        accPasswordStore = "";
                        accNumber = -1;
                        display1 = "";
                        display2 = lang.displayTexts[6] + lang.displayTexts[7];// "Input New Account Password ( Pair was Different )";
                        display3 = "";
                    }
                    else if (accPasswd.length() < 5){
                        number = 0;
                        accPasswd = "";
                        accPasswordStore = "";
                        accNumber = -1;
                        display1 = "";
                        display2 = lang.displayTexts[6] + lang.displayTexts[8];//"Input New Account Password ( Password must have more than 4 digits )";
                        display3 = "";
                    }
                    else
                    {
                        //now do security validation
                        String firstPart = accPasswd.substring(0,1);
                        boolean tooSimple = true;
                        for (int i = 1;i<accPasswd.length();i++)
                        {
                            if (!firstPart.equals(accPasswd.substring(i, i + 1)))
                            {
                                System.out.println(accPasswd.substring(i, i + 1) + " is diffrent to " + firstPart);
                                tooSimple = false;
                                break;
                            }
                        }
                        if(tooSimple)
                        {
                            number = 0;
                            accPasswd = "";
                            accPasswordStore = "";
                            accNumber = -1;
                            display1 = "";
                            display2 = lang.displayTexts[6] + lang.displayTexts[9];//"Input New Account Password ( Password must not contain only one number )";
                            display3 = "";
                        }
                        else{
                            //make account and go back
                            System.out.println("Account created");
                            bank.addBankAccount(accPasswd);
                            isClosing = true;
                            processFinish();
                        }
                    }
                    view.update();
                    //uinputing second password
                }
                break;
            case DEPOSIT:
                processDeposit();
                break;
            case LOGGED_IN:
                Debug.trace("DEBUG | Model::processEnter() case LOGGED_IN");
                break;
            case SETTINGS:
                Debug.trace("DEBUG | Model::processEnter() case SETTINGS");
                break;
            case MONEYTRANSFER:
                Debug.trace("DEBUG | Model::processEnter() case MONEYTRANSFER");
                if (Objects.equals(accPasswd, " "))
                {
                    display2 = lang.displayTexts[10] + " " + bank.account.accNumber + "\n"+lang.displayTexts[11]+" *** \n"+lang.displayTexts[12]+" " + bank.account.getBalance() +
                               "\n"+lang.displayTexts[18]+" ["+ number +"] --> [" + accNumber + "] ";
                    if (bank.transferMoney(accNumber,number))
                    {//lang.displayTexts[6] + lang.displayTexts[7];//
                        display2 += lang.displayTexts[20];

                        if (bank.account.isLow())
                        {
                            display2 += "\n"+lang.displayTexts[22];
                        }
                        receipt += "\nTransfer ["+ number +"] to [" + accNumber + "] Completed";
                    }
                    else{
                        display2 += lang.displayTexts[21];
                        receipt += "\nTransfer ["+ number +"] to [" + accNumber + "] Failed";
                    }
                    setState(MANAGMENT);
                    ProcessTransfer(true);
                }
                else{
                    accNumber = number;
                    number = 0;
                    accPasswd = " ";
                }
                break;
            default:
        }
        view.update();  // update the GUI
        return isClosing;
    }

    public void openSettings()
    {
        Debug.trace("DEBUG | Model::processAccount() setState(SETTINGS)");
        setState(SETTINGS);
        display2 = lang.displayTexts[10] + " " + bank.account.accNumber + "\n"+lang.displayTexts[12]+" " + bank.account.getBalance() +"\n"+lang.displayTexts[13]+" "+ bank.account.getOverdraft();
        view.changeScene("Settings");
    }

    public void processWithdraw() {

        if (state.equals(MANAGMENT))
        {
            view.changeScene("Input");
            setState(WITHDRAW);
            title = lang.titleTexts[3];
            display1 = "";
            display2 = "";
            number = 0;
        }
        else {
            int withdrawResult = bank.account.withdraw(number);
            if (withdrawResult == 1) {
                bank.account.updateAccountData(bank);
//                if (!Objects.equals(display2, ""))
//                {
//                    display2 += "\n";
//                }
                display2 += lang.displayTexts[14]+" " + number + "\n";
                if (bank.account.isLow())
                {
                    display2 += lang.displayTexts[22] + "\n";
                }
                receipt += "\nMoney Withdrawn: " + number;
            } else if (withdrawResult == 2) {
                display2 = lang.displayTexts[23];
            } else {
                display2 = lang.displayTexts[24];
            }
            number = 0;
            display1 = "";
        }
        view.update();
    }
    public void processNo()
    {
        if (state.equals(ACCOUNTCREATION))
        {
            processFinish();
        }
        else{
            toTransition();
        }
    }
    public void ProcessTransfer(boolean changeDisplay)
    {
        if (state.equals(MANAGMENT))
        {
            accPasswd = "";
            setState(MONEYTRANSFER);
            display1 = "";
            if (!changeDisplay)
            {
                //lang.displayTexts[10] + " " + bank.account.accNumber + "\n"+lang.displayTexts[11]+" *** \n" +lang.displayTexts[12] + " " + bank.account.getBalance();
                display2 = lang.displayTexts[10] + " " + bank.account.accNumber + "\n"+lang.displayTexts[11]+" *** \n" +lang.displayTexts[12] + " " + bank.account.getBalance();
                //display2 = "Account Number: " + bank.account.accNumber + "\nAccount Password: *** \nAccount Balance: " + bank.account.getBalance();
                //display2 = "Account Number: " + bank.account.accNumber + "\nAccount Password: *** \nAccount Balance: " + bank.account.getBalance();
            }
            display3 = "";
            title = lang.titleTexts[4];
            titl2 = lang.titleTexts[8];
            number = 0;
            view.changeScene("DoubleInput");
        }
    }
    public void processYes()
    {
        if (state.equals(ACCOUNTCREATION))
        {
            accNumber = -1;
            accPasswd = "";
            setState(ACCOUNTCREATION);
            display1 = "";//numbers appear here
            display2 = lang.displayTexts[27]+" : " + bank.nextAccountNumber + "\n" +
                    lang.displayTexts[29]+" ### \n" +
                    "Account type : BASIC";//data apears here
            display3 = "";
            title = lang.titleTexts[5];
            titl2 = lang.titleTexts[9];
            number = 0;
            view.changeScene("DoubleInputPass");
        }
        else{
            toTransition();
        }
    }
    public void createAccount()
    {
        if (state.equals(ACCOUNT_NO) || state.equals(ACCOUNTCREATION))
        {
            display1 = lang.displayTexts[0];//  "Would you like to create a new account?";
            view.changeScene("ConfirmMenu");
            view.update();
            setState(ACCOUNTCREATION);
        }
    }
    // Deposit button - check we are logged in and if so try and deposit some money into
    // the bank (number is the amount showing in the interface display)
    public void processDeposit() {
        if (state.equals(MANAGMENT))
        {
            view.changeScene("Input");
            setState(DEPOSIT);
            title = lang.titleTexts[6];
            display1 = "";
            display2 = "";
            number = 0;
        }
        else{
            if (bank.deposit(number)) {
                display1 = "";
                display2 += lang.displayTexts[15]+" " + number + "\n";
                receipt += "\nMoney Deposited: " + number;
                number = 0;
            } else {
                display2 = lang.displayTexts[25] +
                        "\n"+lang.displayTexts[26];
            }
        }
        view.update();  // update the GUI
    }

    public void processBalance() {
        if (state.equals(LOGGED_IN) || state.equals(SETTINGS)) {
            view.changeScene("Default");
            number = 0;
            display1 = "";
            display2 = lang.displayTexts[12]+" " + bank.account.getBalance() +
                    "\n "+lang.displayTexts[14]+" " + bank.account.getOverdraft();
        } else {
            initialise("You are not logged in");
        }
        view.update();  // update the GUI
    }

    // Finish button - check we are logged in and if so log out
    public void resetData()
    {
        receipt = "";
        view.closeReceipt();
        initialise(lang.displayTexts[28]);
        setState(ACCOUNT_NO);
        number = 0;
        bank.logout();
    }
    public void processFinish() {
        view.playButtonSound("Close.mp3");
        resetData();
        Debug.trace("DEBUG | Model::processFinish()");
        display2 = lang.displayTexts[28];
        view.changeScene("Start");
        view.update(); // Update Gui
    }
    public void proccessLogin()
    {
        resetData();
        Debug.trace("DEBUG | Model::proccessLogin()");
        display2 = "";
        display1 = "";
        title = lang.titleTexts[7];
        view.changeScene("Login");
        view.update(); // Update Gui
    }

    // Any other key results in an error message and a reset of the GUI
    public void processUnknownKey(String action) {
        // unknown button, or invalid for this state - reset everything
        Debug.trace("DEBUG | Model::processUnknownKey() | unknown button \"" + action + "\", re-initialising");
        // go back to initial state
        initialise("Invalid command");
        view.update();
    }

    public void processAccount() {
        Debug.trace("DEBUG | Model::processAccount()");
        if (state.equals(MANAGMENT))
        {
            openSettings();
        }
        view.update();
    }
    public void processBack()
    {
        if (state.equals(ACCOUNTCREATION))
        {
            createAccount();
           // openSettings();

        }
        else if (state.equals(ACCOUNT_NO) || state.equals(PASSWORD))
        {
            processFinish();
        }
        else{
            toTransition();
        }
    }
}

